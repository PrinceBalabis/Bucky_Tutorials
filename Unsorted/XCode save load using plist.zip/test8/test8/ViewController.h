//
//  ViewController.h
//  test8
//
//  Created by Prince Stevie-Ray Charles Balabis on 25/12/13.
//  Copyright (c) 2013 Prince Stevie-Ray Charles Balabis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    
    
    IBOutlet UILabel *label1;
    IBOutlet UILabel *label2;
    IBOutlet UILabel *label3;
    
}

// METHODSDECLARATIONS TO COPY
-(IBAction)saveLocally:(id)sender;
-(IBAction)loadLocally:(id)sender;

@end
