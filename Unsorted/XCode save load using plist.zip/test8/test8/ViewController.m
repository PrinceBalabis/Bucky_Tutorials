//
//  ViewController.m
//  test8
//
//  Created by Prince Stevie-Ray Charles Balabis on 25/12/13.
//  Copyright (c) 2013 Prince Stevie-Ray Charles Balabis. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

//METHODDECLARATIONS TO COPY
-(IBAction)saveLocally:(id)sender
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *stringsPlistPath = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"Strings.plist"];
    
    NSString *string1 = @"test1";
    NSString *string2 = @"test2";
    NSString *string3 = @"test3";
    NSArray *stringsArray = @[string1, string2, string3];
    
    [stringsArray writeToFile:stringsPlistPath atomically:YES];
}

-(IBAction)loadLocally:(id)sender
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *stringsPlistPath = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"Strings.plist"];
    
    NSArray *stringsArray = [NSArray arrayWithContentsOfFile:stringsPlistPath];
    
    label1.text = stringsArray[0];
    label2.text = stringsArray[1];
    label3.text = stringsArray[2];
}

// STOP COPY HERE

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
